package net.mosus.grunglecraft;

import net.fabricmc.api.ClientModInitializer;

public class GrunglecraftClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
